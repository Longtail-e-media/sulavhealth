<?php
phpinfo();

// var_dump(curl_version());